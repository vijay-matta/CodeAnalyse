﻿using CodeLineCounterApp.Services;


namespace CodeLineCounterApp.Tests
{
    [TestFixture]
    public class LineCounterServiceTests
    {
        private LineCounterService _service;

        [SetUp]
        public void Setup() => _service = new LineCounterService();

        [Test]
        public async Task CountLinesAsync_ReturnsCorrectCount_ForStandardFile()
        {
            string path = Path.GetTempFileName();
            await File.WriteAllLinesAsync(path, new[] { "line1", "line2", "line3" });
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(3));
            File.Delete(path);
        }

        [Test]
        public async Task CountLinesAsync_ReturnsZero_ForEmptyFile()
        {
            string path = Path.GetTempFileName();
            await File.WriteAllTextAsync(path, "");
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(0));
            File.Delete(path);
        }

        [Test]
        public void CountLinesAsync_ThrowsOnNullPath()
        {
            Assert.ThrowsAsync<ArgumentNullException>(() => _service.CountLinesAsync(null));
        }

        [Test]
        public void CountLinesAsync_ThrowsOnMissingFile()
        {
            Assert.ThrowsAsync<FileNotFoundException>(() => _service.CountLinesAsync("nonexistent.cs"));
        }

        [Test]
        public async Task CountLinesAsync_HandlesLongFileGracefully()
        {
            string path = Path.GetTempFileName();
            var lines = Enumerable.Repeat("test line", 1000);
            await File.WriteAllLinesAsync(path, lines);
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(1000));
            File.Delete(path);
        }

        [Test]
        public async Task CountLinesAsync_IgnoresBlankLines()
        {
            string path = Path.GetTempFileName();
            await File.WriteAllLinesAsync(path, new[] { "", "code", "" });
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(3)); // still physical lines
            File.Delete(path);
        }

        [Test]
        public async Task CountLinesAsync_FileWithSingleLine_ReturnsOne()
        {
            string path = Path.GetTempFileName();
            await File.WriteAllTextAsync(path, "single line");
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(1));
            File.Delete(path);
        }

        [Test]
        public async Task CountLinesAsync_FileWithUnixNewlines()
        {
            string path = Path.GetTempFileName();
            await File.WriteAllTextAsync(path, "a\nb\nc");
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(3));
            File.Delete(path);
        }

        [Test]
        public async Task CountLinesAsync_FileWithWindowsNewlines()
        {
            string path = Path.GetTempFileName();
            await File.WriteAllTextAsync(path, "a\r\nb\r\nc");
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(3));
            File.Delete(path);
        }

        [Test]
        public async Task CountLinesAsync_FileWithMixedNewlines()
        {
            string path = Path.GetTempFileName();
            await File.WriteAllTextAsync(path, "a\nb\r\nc");
            var result = await _service.CountLinesAsync(path);
            Assert.That(result, Is.EqualTo(3));
            File.Delete(path);
        }
    }


}
