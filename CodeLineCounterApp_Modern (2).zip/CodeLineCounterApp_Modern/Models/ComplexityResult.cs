﻿namespace CodeLineCounterApp.Models
{
    public class ComplexityResult
    {
        public string FileName { get; set; } = string.Empty;
        public int CyclomaticComplexity { get; set; }
        public int ClassCoupling { get; set; }
    }
}