﻿using CodeLineCounterApp.Contracts;
using Serilog;
namespace CodeLineCounterApp.Services
{
    public class SerilogLoggerService : ILoggerService
    {
        public void LogInfo(string message, params object[] args)
        {
            Log.Information(message, args);
        }
        public void LogError(string message, params object[] args)
        {
            Log.Error(message, args);
        }
        public void LogDebug(string message, params object[] args)
        {
            Log.Debug(message, args);
        }
    }
}