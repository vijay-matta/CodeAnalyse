﻿namespace CodeLineCounterApp.Contracts
{
    public interface ILoggerService
    {
        void LogInfo(string message, params object[] args);
        void LogError(string message, params object[] args);
        void LogDebug(string message, params object[] args);
    }
}