using System.Threading.Tasks;

namespace CodeLineCounterApp.Contracts;

public interface IMethodCounter
{
    Task<int> CountMethodsAsync(string code);
}