using System.Threading.Tasks;

namespace CodeLineCounterApp.Contracts;

public interface ILineCounter
{
    Task<int> CountLinesAsync(string filePath);
}