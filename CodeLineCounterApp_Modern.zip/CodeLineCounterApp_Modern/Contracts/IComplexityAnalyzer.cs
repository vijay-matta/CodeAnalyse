﻿using CodeLineCounterApp.Models;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Contracts
{
    public interface IComplexityAnalyzer
    {
        Task<ComplexityResult> AnalyzeAsync(string filePath, string code);
    }
}