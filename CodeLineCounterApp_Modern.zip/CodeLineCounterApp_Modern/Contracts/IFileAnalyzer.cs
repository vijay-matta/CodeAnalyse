using CodeLineCounterApp.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Contracts
{
    public interface IFileAnalyzer
    {
        Task<List<FileAnalysisResult>> AnalyzeFilesAsync(LoadConfigdto settings, string rootPath, bool includeSubfolders);
    }
}