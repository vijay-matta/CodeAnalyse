﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Services;
using CodeLineCounterApp.ViewModels;
using CodeLineCounterApp.Views;
using Microsoft.Extensions.DependencyInjection;
namespace CodeLineCounterApp
{
    public static class Startup
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            // Register ViewModels
            services.AddSingleton<MainViewModel>();
            // Register Services
            services.AddSingleton<ILineCounter, LineCounterService>();
            services.AddSingleton<IMethodCounter, MethodCounterService>();
            services.AddSingleton<IFileAnalyzer, FileAnalyzerService>();
            services.AddSingleton<ILoggerService, SerilogLoggerService>();
            
            services.AddSingleton<IComplexityAnalyzer, ComplexityAnalyzerService>();

            // Register Views
            services.AddSingleton<MainWindow>(provider =>
            {
                return new MainWindow
                {
                    DataContext = provider.GetRequiredService<MainViewModel>()
                };
            });
        }
    }
}