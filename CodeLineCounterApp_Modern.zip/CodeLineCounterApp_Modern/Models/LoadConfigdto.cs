using System.Collections.Generic;

namespace CodeLineCounterApp.Models;

public class LoadConfigdto
{
    public List<string> IncludedExtensions { get; set; } = new();
    public List<string> ExcludedPaths { get; set; } = new();
}